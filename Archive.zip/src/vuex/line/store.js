import * as actions from './action';

const store = {
    state: {
        listTrainLine: null,
    },
    mutations: {
    },
    actions,
    getters:{
    }
};
export default store;