<template>
<div class="col-9">
    <section class="group-content-candidate__ha width-133">

        <div class="translate__form">
            <div class="translate__form__header">
                <div class="row mb-3">
                    <div class="col-3">
                        <div>
                            <select name="" id="" class="input-text__ha">
                                <option value="">non-translate</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-3">
                        <div>
                            <select name="" id="" class="input-text__ha">
                                <option value="">Vietnamese</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-3">
                        <div>
                            <select name="" id="" class="input-text__ha">
                                <option value="">City./Ward</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-3">
                        <div>
                            <input type="text" class="input-text__ha" placeholder="Employer">
                        </div>
                    </div>
                    <div class="col-3">
                        <div>
                            <input type="text" class="input-text__ha" placeholder="Location">
                        </div>
                    </div>
                    <div class="col-3">
                        <div>
                            <select name="" id="" class="input-text__ha">
                                <option value="">Prefecture</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col text-center">
                        <div class="btn__wrapper">
                            <button class="btn__search">
                                Search
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="translate__form__content">
                <div class="table-responsive">
                    <table class="table table-bordered table-applied-jobs">
                        <thead>
                            <tr>
                                <th class="text-bold">
                                    ID
                                    <div class="form-search-header">
                                        <input type="text" class="search-detail" placeholder="Search">
                                    </div>
                                </th>
                                <th class="text-bold">
                                    Job name
                                    <div class="form-search-header">
                                        <input type="text" class="search-detail" placeholder="Search">
                                    </div>
                                </th>
                                <th class="text-bold">Location</th>
                                <th class="text-bold">Workplace</th>
                                <th class="text-bold">Nearest Static</th>
                                <th class="text-bold">
                                    Posting date
                                </th>
                                <th class="text-bold">Closing date</th>
                                <th class="text-bold">Action</th>
                                <th class="text-bold">Translate</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1123</td>
                                <td>[Urgent] Foreigners are welcome! Recruitment of hall staff in
                                    the morning! Have</td>
                                <td>Marugame Seikan Takadanobo</td>
                                <td>1-2-3 takad</td>
                                <td>Toshiama-ku</td>
                                <td>Tokyo takadaboba Station</td>
                                <td>2019-11-15</td>
                                <td>2019-11-30</td>
                                <td>
                                    <div class="d-flex">
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/vietnam.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper mr-10 inactive">
                                            <img src="assets/images/flag/japan.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/korea.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/china.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper">
                                            <img src="assets/images/flag/england.png" alt="language">
                                        </div>

                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>1123</td>
                                <td>[Urgent] Foreigners are welcome! Recruitment of hall staff in
                                    the morning! Have</td>
                                <td>Marugame Seikan Takadanobo</td>
                                <td>1-2-3 takad</td>
                                <td>Toshiama-ku</td>
                                <td>Tokyo takadaboba Station</td>
                                <td>2019-11-15</td>
                                <td>2019-11-30</td>
                                <td>
                                    <div class="d-flex">
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/vietnam.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/japan.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/korea.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/china.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper">
                                            <img src="assets/images/flag/england.png" alt="language">
                                        </div>

                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>1123</td>
                                <td>[Urgent] Foreigners are welcome! Recruitment of hall staff in
                                    the morning! Have</td>
                                <td>Marugame Seikan Takadanobo</td>
                                <td>1-2-3 takad</td>
                                <td>Toshiama-ku</td>
                                <td>Tokyo takadaboba Station</td>
                                <td>2019-11-15</td>
                                <td>2019-11-30</td>
                                <td>
                                    <div class="d-flex">
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/vietnam.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/japan.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/korea.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/china.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper">
                                            <img src="assets/images/flag/england.png" alt="language">
                                        </div>

                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>1123</td>
                                <td>[Urgent] Foreigners are welcome! Recruitment of hall staff in
                                    the morning! Have</td>
                                <td>Marugame Seikan Takadanobo</td>
                                <td>1-2-3 takad</td>
                                <td>Toshiama-ku</td>
                                <td>Tokyo takadaboba Station</td>
                                <td>2019-11-15</td>
                                <td>2019-11-30</td>
                                <td>
                                    <div class="d-flex">
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/vietnam.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/japan.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/korea.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/china.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper">
                                            <img src="assets/images/flag/england.png" alt="language">
                                        </div>

                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>1123</td>
                                <td>[Urgent] Foreigners are welcome! Recruitment of hall staff in
                                    the morning! Have</td>
                                <td>Marugame Seikan Takadanobo</td>
                                <td>1-2-3 takad</td>
                                <td>Toshiama-ku</td>
                                <td>Tokyo takadaboba Station</td>
                                <td>2019-11-15</td>
                                <td>2019-11-30</td>
                                <td>
                                    <div class="d-flex">
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/vietnam.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/japan.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/korea.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/china.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper">
                                            <img src="assets/images/flag/england.png" alt="language">
                                        </div>

                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>1123</td>
                                <td>[Urgent] Foreigners are welcome! Recruitment of hall staff in
                                    the morning! Have</td>
                                <td>Marugame Seikan Takadanobo</td>
                                <td>1-2-3 takad</td>
                                <td>Toshiama-ku</td>
                                <td>Tokyo takadaboba Station</td>
                                <td>2019-11-15</td>
                                <td>2019-11-30</td>
                                <td>
                                    <div class="d-flex">
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/vietnam.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/japan.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/korea.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper mr-10">
                                            <img src="assets/images/flag/china.png" alt="language">
                                        </div>
                                        <div class="translate__logo__wrapper">
                                            <img src="assets/images/flag/england.png" alt="language">
                                        </div>

                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </section>
</div>
</template>

<script>
import {
    mapActions,
    mapGetters
} from 'vuex';

export default {
    data() {
        return {
            objData: '',
        }
    },
    components: {

    },
    watch: {

    },
    computed: {

    },
    methods: {
        ...mapActions(['getDetailEmployerPost']),
        getDetail() {
            let loading = this.$loading.show();
            this.getDetailEmployerPost({
                    id: this.$route.params.id
                })
                .then(res => {
                    this.objData = res;
                    loading.hide();
                    console.log('rrr', res)
                })
                .catch(err => {

                })
        },
    },
    created() {

    },
    mounted() {
        this.getDetail();
        console.log('aas', this.objData);
    },
}
</script>
