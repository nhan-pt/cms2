<template>
    <div>
        <p>
            <img src="/img/404444.png" />
        </p>
        <!--{{$t("Label.System.404Message")}}-->
    </div>
</template>
<style scoped>
    i { font-size: 30px; }
    div { margin: 200px auto; text-align: center; font-size: 15px; }
</style>