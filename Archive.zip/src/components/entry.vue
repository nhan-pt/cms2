﻿<template>
    <app-wrapper />
</template>
<script>
    import appWrapper from './app-wrapper';
   
    export default {
        name: 'entry',
        components: { appWrapper }        
    }
</script>