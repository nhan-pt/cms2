module.exports = (file) => {
        return require(`../components/${file}.vue`).default
}//vue-loader v13.0.0+
